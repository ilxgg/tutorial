class Enemy {
    constructor(scene, x, y, texture, player){
        this.scene = scene;
        this.x = x;
        this.y = y;
        this.speed = 60;
        this.player = player;
        this.range = 60;
        this.sprite = this.scene.physics.add.sprite(this.x, this.y, texture)
        .setSize(22,29);
        this.sprite.body.bounce.setTo(1,0);
    }

    initMovement(){
        this.sprite.setVelocityX(this.speed);
        this.sprite.anims.play('enemy-run', true);
    }

    update(){
        try{

            this.tryChasePlayer();
            if(this.sprite.body.angle < 1){
                this.sprite.flipX = false;
            }else if(this.sprite.body.angle > 3){
                this.sprite.flipX = true;
        }
        }catch(e){

        }
    }

    tryChasePlayer(){
        if(Phaser.Math.Distance.Between(this.sprite.x, this.sprite.y, this.player.sprite.x, this.player.sprite.y) <= this.range 
        && this.sprite.y + this.sprite.height > this.player.sprite.y 
        && this.sprite.y < this.player.sprite.y + this.player.sprite.height){
            
            if(this.sprite.x < this.player.sprite.x){
                this.sprite.setVelocityX(this.speed);
            } else if(this.sprite.x > this.player.sprite.x){
                this.sprite.setVelocityX(-this.speed);
            }
        }
    }
}