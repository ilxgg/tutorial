class LevelOne extends BaseScene{
    
    create(){
        super.create();
        
    }

    update(){
        super.update();
    }
}