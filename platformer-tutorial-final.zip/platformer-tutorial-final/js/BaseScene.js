class BaseScene extends Phaser.Scene{

    map;
    player;
    playerSpawn;
    enemies = [];
   
    preload(){
        //load all textures and images
        this.load.image('tileset', 'assets/textures/Enviroment.png');
        this.load.image('middleGround', 'assets/textures/Midleground-Extended.png');
        //this.load.image('background', 'assets/textures/Background-Extended.png');
        this.load.image('backgroundGreen', 'assets/textures/Background-Extended-Green.png');


        //load tilemap
        this.load.tilemapTiledJSON('levelOne', 'assets/levels/level-one.json');
        this.load.spritesheet('player', 'assets/textures/adventurer-Sheet.png', {
            frameWidth: 50,
            frameHeight: 37
        });
        this.load.spritesheet('enemy', 'assets/textures/Zombie.png', {
          frameWidth:32,
          frameHeight: 32
        })


    }

    create(){
        //create tilemap
        this.map = this.make.tilemap({key: 'levelOne'});
        this.physics.world.setBounds(0,0, this.map.widthInPixels, this.map.heightInPixels);

        //create tileset arrays
        let tileset = this.map.addTilesetImage('Enviroment', 'tileset');
        let backgroundGreen = this.map.addTilesetImage('Background-Extended-Green', 'backgroundGreen');
        let middleGround = this.map.addTilesetImage('Midleground-Extended', 'middleGround');

        this.map.createLayer('background', [backgroundGreen], 0,0).setScrollFactor(0.3, 1);
        this.map.createLayer('middleground', [middleGround], 0,0).setScrollFactor(0.5, 1);
        this.map.createLayer('background-cave', [tileset], 0, 0);
        this.map.createLayer('trees', [tileset], 0,0);
        let ground = this.map.createLayer('ground', [tileset], 0,0);
        this.map.createLayer('decoration', [tileset], 0,0);

        ground.setCollisionBetween(1, 2000);



        //creates animations for the player
        this.anims.create({
            key: 'idle',
            frames: this.anims.generateFrameNumbers('player', {start: 0, end: 3}),
            frameRate: 8,
            repeat: -1
        });
        this.anims.create({
            key:'run',
            frames: this.anims.generateFrameNumbers('player', {start: 8, end: 13}),
            frameRate: 10,
            repeat: -1
        });
        this.anims.create({
            key: 'jump-1',
            frames: this.anims.generateFrameNumbers('player', {start: 14, end: 17}),
            frameRate: 20,
            repeat: 0
        });
        this.anims.create({
            key: 'jump-2',
            frames: this.anims.generateFrameNumbers('player', {start: 17, end: 22}),
            frameRate: 20,
            repeat: 0
        });
        this.anims.create({
            key: 'fall',
            frames: this.anims.generateFrameNumbers('player', {start: 22, end: 23}),
            frameRate: 10,
            repeat: -1
        });
        this.anims.create({
          key: 'enemy-run',
          frames: this.anims.generateFrameNumbers('enemy', {start: 26, end:33}),
          frameRate: 8,
          repeat: -1
        });




        


        let objectLayer = this.map.getObjectLayer('objectLayer');

        let tempEnemies = [];

        objectLayer.objects.forEach(
          function(object){
              let obj = BaseScene.RetrieveCustomProperties(object);
              if(obj.type == 'spawn'){
                
                  if(obj.name == 'player'){
                    this.playerSpawn = obj;
                  } else if(obj.name == 'enemy'){
                    tempEnemies.push(obj);
                  }
              }
          }, this

      );

      //player
      this.player = new Player(this, this.playerSpawn.x, this.playerSpawn.y, 'player', this.input.keyboard.createCursorKeys());


      //enemies
      for(let i = 0; i <tempEnemies.length; i++){
        this.createEnemy(tempEnemies[i], ground);
      }

        


        this.physics.add.collider(this.player.sprite, ground);

        //camera
        this.camera = this.cameras.getCamera("");
        this.camera.setBounds(0, 0, this.map.widthInPixels, this.map.heightInPixels);
        this.camera.startFollow(this.player.sprite);

    }

    update(){
    
        this.player.update();

        for(let i =0; i<this.enemies.length; i++){
          this.enemies[i].update();
        }
    }

    createEnemy(obj, ground){
      let enemy = new Enemy(this, obj.x, obj.y, 'enemy', this.player);
      this.physics.add.collider(enemy.sprite, ground);
      this.physics.add.overlap(enemy.sprite, this.player.sprite, this.endGame, null, this);
      enemy.initMovement();
      this.enemies.push(enemy);
    }

    endGame(){
      this.scene.restart();
    }
    


    
    // retrieve custom properties of Tiled object
    static RetrieveCustomProperties(object) {
      if(object.properties) { //Check if the object has custom properties
          if(Array.isArray(object.properties)) { //Check if from Tiled v1.3 and above
              object.properties.forEach(function(element){ //Loop through each property
                  this[element.name] = element.value; //Create the property in the object
              }, object); //Assign the word "this" to refer to the object
          } else {  //Check if from Tiled v1.2.5 and below
              for(var propName in object.properties) { //Loop through each property
                  object[propName] = object.properties[propName]; //Create the property in the object
              }
          }
          delete object.properties; //Delete the custom properties array from the object
      }
      return object; //Return the new object w/ custom properties
  }
    static FindPoint(map, layer, type, name) {
        var loc = map.findObject(layer, function (object) {
          if (object.type === type && object.name === name) {
            return object;
          }
        });
        return loc
      }
    static FindPoints(map, layer, type) {
        var locs = map.filterObjects(layer, function (object) {
          if (object.type === type) {
            return object
          }
        });
        return locs
      }
}