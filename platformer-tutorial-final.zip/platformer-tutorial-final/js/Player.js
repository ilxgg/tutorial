class Player{
    constructor(scene, x, y, texture, keys){
        this.scene = scene;
        this.keys = keys;
        this.x = x;
        this.y = y;
        this.jumpCount = 0;
        this.jumpCheck = 0;

        //loads player's texture
        this.sprite = this.scene.physics.add.sprite(this.x, this.y, texture)
        .setSize(20,30,true);

        this.sprite.body.collideWorldBounds = true;

        

    }

    update(){   //funtion to be called in order to update the player object
        this.movement();
    }

    movement(){

        if(this.sprite.body.blocked.down){
            this.jumpCheck++;
            if(this.jumpCheck>20){
                this.jumpCount =0;
                this.jumpCheck =0;
            }
            
        }
        if(this.keys.left.isDown){

            
            if(this.sprite.body.blocked.down) {
                this.sprite.anims.play('run', true);
                this.sprite.setVelocityX(-160);
            } else if(!this.sprite.body.blocked.down){
                this.sprite.anims.chain('fall', true);
                this.sprite.setVelocityX(-160);
            }
            
            this.sprite.flipX = true;
        }else if(this.keys.right.isDown){

            
            if(this.sprite.body.blocked.down) {
                this.sprite.anims.play('run', true);
                this.sprite.setVelocityX(160);
            } else if(!this.sprite.body.blocked.down){
                this.sprite.anims.chain('fall', true);
                this.sprite.setVelocityX(160);
            }
            this.sprite.flipX = false;
        } else{
            this.sprite.setVelocityX(0);
        }

        
        if(Phaser.Input.Keyboard.JustDown(this.keys.up)){
            
            if(this.jumpCount <1)
            {
                this.sprite.anims.play('jump-1', true);
                this.sprite.anims.chain('fall');
                this.sprite.setVelocityY(-200);
                this.jumpCount++; 
            }else if(this.jumpCount==1)
            {
                this.sprite.anims.play('jump-2', true);
                this.sprite.anims.chain('fall');
                this.sprite.setVelocityY(-200);
                this.jumpCount++;
            }
        }

        if(this.sprite.body.speed == 0 && this.sprite.body.blocked.down){
            this.sprite.anims.play('idle', true);
            
        }
    }
}